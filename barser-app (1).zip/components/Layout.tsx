
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  title: string;
  role: string;
}

const Layout: React.FC<LayoutProps> = ({ children, title, role }) => {
  return (
    <div className="min-h-screen bg-[#FDFDFD] flex flex-col items-center">
      {/* App Container */}
      <div className="w-full max-w-md bg-white min-h-screen shadow-[0_0_100px_rgba(0,0,0,0.03)] relative flex flex-col overflow-hidden">
        
        {/* Luxury Header */}
        <header className="glass border-b border-slate-50/50 p-5 sticky top-0 z-[60] flex justify-between items-center px-6">
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 bg-slate-950 rounded-2xl flex items-center justify-center shadow-lg shadow-slate-900/10">
              <span className="text-xl">✂️</span>
            </div>
            <div className="flex flex-col">
              <h1 className="text-lg font-extrabold text-slate-950 leading-none tracking-tight">Barser</h1>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="w-1 h-1 bg-amber-500 rounded-full"></span>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">{role}</span>
              </div>
            </div>
          </div>
          
          <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-[12px]">
            🔔
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto pb-32 no-scrollbar scroll-smooth">
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
