
import React, { useState, useMemo } from 'react';
import { SERVICES, MOCK_USERS } from '../constants';
import { Service, User, Booking, BookingStatus, UserRole, AreaLocation } from '../types';
import LocationSelector from './LocationSelector';

interface UserPanelProps {
  user: User;
  onAddBooking: (booking: Booking) => void;
  bookings: Booking[];
  allBookings: Booking[];
  onLogout: () => void;
}

const TIME_SLOTS = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00', '18:00'];

const UserPanel: React.FC<UserPanelProps> = ({ user, onAddBooking, bookings, allBookings, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'home' | 'bookings' | 'profile'>('home');
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [step, setStep] = useState(1);
  const [selectedBarber, setSelectedBarber] = useState<User | null>(null);
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [bookingArea, setBookingArea] = useState<AreaLocation | undefined>(user.location);
  const [address, setAddress] = useState('');

  const allBarbers = MOCK_USERS.filter(u => u.role === UserRole.BARBER);

  const filteredBarbers = useMemo(() => {
    if (!bookingArea) return allBarbers;

    const villageMatch = allBarbers.filter(b => 
      b.location?.village?.toLowerCase() === bookingArea.village?.toLowerCase() &&
      b.location?.country === bookingArea.country
    );

    const subDistrictMatch = allBarbers.filter(b => 
      b.location?.subDistrict?.toLowerCase() === bookingArea.subDistrict?.toLowerCase() &&
      b.location?.village?.toLowerCase() !== bookingArea.village?.toLowerCase() &&
      b.location?.country === bookingArea.country
    );

    const districtMatch = allBarbers.filter(b => 
      b.location?.district?.toLowerCase() === bookingArea.district?.toLowerCase() &&
      b.location?.subDistrict?.toLowerCase() !== bookingArea.subDistrict?.toLowerCase() &&
      b.location?.country === bookingArea.country
    );

    const others = allBarbers.filter(b => !villageMatch.includes(b) && !subDistrictMatch.includes(b) && !districtMatch.includes(b));

    return [...villageMatch, ...subDistrictMatch, ...districtMatch, ...others];
  }, [bookingArea, allBarbers]);

  const getProximityBadge = (barber: User) => {
    if (!bookingArea || !barber.location) return { text: 'Verified', color: 'bg-slate-400', icon: '✓' };
    
    if (barber.location.village?.toLowerCase() === bookingArea.village?.toLowerCase()) {
      return { text: 'Local Pro', color: 'bg-emerald-500', icon: '📍' };
    }
    if (barber.location.subDistrict?.toLowerCase() === bookingArea.subDistrict?.toLowerCase()) {
      return { text: 'Nearby', color: 'bg-amber-500', icon: '⚡' };
    }
    return { text: 'Regional', color: 'bg-slate-400', icon: '🚗' };
  };

  const getServicePrice = (barber: User | null, service: Service | null) => {
    if (!service) return 0;
    return barber?.servicePrices?.[service.id] || service.price;
  };

  const currentPrice = useMemo(() => getServicePrice(selectedBarber, selectedService), [selectedBarber, selectedService]);

  const handleCreateBooking = () => {
    if (selectedService && selectedBarber && bookingDate && bookingTime && bookingArea) {
      onAddBooking({
        id: `bk-${Date.now()}`,
        userId: user.id,
        barberId: selectedBarber.id,
        serviceId: selectedService.id,
        date: bookingDate,
        time: bookingTime,
        status: BookingStatus.PENDING,
        totalPrice: currentPrice,
        address: `${address || 'Home Address'}, ${bookingArea.village}`,
        location: bookingArea,
        userName: user.name,
        serviceName: selectedService.name,
        barberName: selectedBarber.name,
        timestamp: Date.now(),
      });
      setStep(4);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {activeTab === 'home' && (
        <div className="space-y-10 animate-in fade-in slide-in-from-bottom-2 duration-700">
          <div className="px-7 pt-8">
            <p className="text-[10px] font-black text-amber-500 uppercase tracking-[0.3em] mb-1">Welcome Back</p>
            <h2 className="text-3xl font-extrabold text-slate-950 tracking-tight text-left">{user.name.split(' ')[0]}</h2>
            <div className="flex items-center gap-2 mt-4 bg-slate-50 w-fit py-2 px-4 rounded-2xl border border-slate-100/50">
               <span className="w-2 h-2 bg-emerald-500 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.3)]"></span>
               <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest truncate max-w-[220px]">
                {bookingArea ? `${bookingArea.village}, ${bookingArea.country}` : 'Set Location'}
               </p>
            </div>
          </div>

          {/* Luxury Banner */}
          <div className="px-7">
            <div className="h-52 bg-slate-950 rounded-[2.5rem] p-9 relative overflow-hidden shadow-premium group transition-all hover:scale-[1.01]">
               <div className="relative z-10 h-full flex flex-col justify-between">
                 <div>
                   <span className="bg-amber-500 text-slate-950 text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest">Exclusive</span>
                   <h3 className="text-3xl font-extrabold text-white mt-4 leading-none">Royal<br/>Treatment</h3>
                 </div>
                 <p className="text-white/40 text-[10px] font-black uppercase tracking-widest">Book Now ➔</p>
               </div>
               <div className="absolute right-[-30px] bottom-[-40px] text-[15rem] opacity-[0.03] rotate-12 select-none pointer-events-none group-hover:scale-110 transition-transform">✂️</div>
            </div>
          </div>

          {/* Services Grid */}
          <div className="px-7">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-extrabold text-slate-950 tracking-tight">Select Service</h3>
              <button className="text-slate-400 text-[10px] font-black uppercase tracking-widest hover:text-slate-950 transition-colors">View All</button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {SERVICES.map(service => (
                <button 
                  key={service.id}
                  onClick={() => { setSelectedService(service); setStep(1); }}
                  className="group flex flex-col p-6 bg-slate-50 border border-slate-100 rounded-[2.2rem] transition-all hover:bg-white hover:shadow-soft hover:border-amber-200 active:scale-95 text-left"
                >
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-2xl shadow-sm mb-5 group-hover:scale-110 transition-transform">{service.icon}</div>
                  <span className="text-sm font-bold text-slate-950 tracking-tight">{service.name}</span>
                  <span className="text-[11px] font-black text-amber-600 mt-2 uppercase tracking-widest">${service.price}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Professional List */}
          <div className="px-7 pb-12">
            <div className="flex justify-between items-center mb-7">
              <h3 className="text-lg font-extrabold text-slate-950 tracking-tight">Top Rated Pros</h3>
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{filteredBarbers.length} Available</span>
            </div>
            <div className="space-y-4">
              {filteredBarbers.length > 0 ? filteredBarbers.map(barber => {
                const badge = getProximityBadge(barber);
                return (
                  <div key={barber.id} className="flex items-center gap-5 p-5 bg-white border border-slate-50 rounded-[2.2rem] shadow-soft hover:shadow-premium transition-all group relative overflow-hidden">
                    <div className={`absolute top-0 right-0 ${badge.color} text-white text-[8px] font-black px-4 py-1.5 rounded-bl-2xl uppercase tracking-tighter`}>
                      {badge.text}
                    </div>
                    <div className="relative">
                      <img src={barber.avatar} className="w-16 h-16 rounded-[1.5rem] object-cover shadow-md group-hover:scale-105 transition-transform" alt="" />
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 border-2 border-white rounded-full"></div>
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-extrabold text-slate-950 text-base">{barber.name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-amber-500 text-[10px] font-black">★ {barber.rating}</span>
                        <span className="text-slate-200 font-bold">•</span>
                        <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest truncate max-w-[100px]">{barber.location?.village || 'Pro'}</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => { setSelectedService(SERVICES[0]); setSelectedBarber(barber); setStep(2); }} 
                      className="bg-slate-950 text-white w-11 h-11 rounded-2xl flex items-center justify-center text-sm active:scale-90 transition-all hover:bg-amber-500 hover:text-slate-950 shadow-lg shadow-slate-950/10"
                    >
                      ➔
                    </button>
                  </div>
                );
              }) : (
                <div className="py-16 bg-slate-50 rounded-[2.5rem] text-center border border-dashed border-slate-200">
                  <p className="text-slate-400 text-sm font-bold">Seeking pros in your area...</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'bookings' && (
        <div className="p-8 space-y-10 animate-in fade-in duration-500 text-left">
          <h2 className="text-3xl font-extrabold text-slate-950 tracking-tight">Booking History</h2>
          {bookings.length === 0 ? (
            <div className="text-center py-28 bg-slate-50 rounded-[3rem]">
              <span className="text-6xl mb-6 block opacity-50">🏷️</span>
              <p className="text-slate-400 font-bold">No sessions yet.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {bookings.sort((a,b) => b.timestamp - a.timestamp).map(booking => (
                <div key={booking.id} className="bg-white border border-slate-50 p-7 rounded-[2.5rem] shadow-soft group text-left transition-all hover:shadow-premium">
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center gap-4">
                       <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-xl shadow-inner">{SERVICES.find(s => s.id === booking.serviceId)?.icon}</div>
                       <div>
                         <h4 className="font-extrabold text-slate-950 text-base">{booking.serviceName}</h4>
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-0.5">With {booking.barberName}</p>
                       </div>
                    </div>
                    <span className={`text-[8px] font-black px-3 py-1.5 rounded-full uppercase tracking-[0.15em] ${
                      booking.status === BookingStatus.COMPLETED ? 'bg-emerald-50 text-emerald-600' :
                      booking.status === BookingStatus.ACCEPTED ? 'bg-blue-50 text-blue-600' :
                      booking.status === BookingStatus.PENDING ? 'bg-amber-50 text-amber-600' : 'bg-red-50 text-red-600'
                    }`}>
                      {booking.status}
                    </span>
                  </div>
                  <div className="flex items-center justify-between pt-6 border-t border-slate-50">
                    <div className="flex flex-col">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Schedule</span>
                      <span className="text-xs font-bold text-slate-950 mt-1">{booking.date} • {booking.time}</span>
                    </div>
                    <span className="text-slate-950 font-black text-lg">${booking.totalPrice}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'profile' && (
        <div className="p-10 space-y-12 animate-in fade-in duration-500 text-center">
           <div className="relative inline-block group">
             <img src={user.avatar} className="w-32 h-32 rounded-[2.8rem] border-4 border-white shadow-premium object-cover transition-transform group-hover:scale-105" alt="profile" />
             <div className="absolute -bottom-1 -right-1 w-11 h-11 bg-slate-950 rounded-2xl border-4 border-white flex items-center justify-center shadow-lg text-lg">💎</div>
           </div>
           
           <div>
             <h3 className="text-3xl font-extrabold text-slate-950 tracking-tight">{user.name}</h3>
             <div className="flex items-center justify-center gap-2 mt-2">
               <span className="text-amber-600 text-[10px] font-black uppercase tracking-[0.2em]">{user.role} Partner</span>
             </div>
           </div>

           <div className="space-y-4">
             <div className="bg-slate-50 p-8 rounded-[2.5rem] text-left border border-slate-100 shadow-inner">
                <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-5">Primary Service Area</h4>
                <LocationSelector 
                  initialValue={user.location} 
                  onSelect={(loc) => setBookingArea(loc)} 
                />
             </div>
             
             <button onClick={onLogout} className="w-full bg-slate-50 p-6 rounded-[2.2rem] flex items-center justify-between text-slate-400 hover:text-red-500 hover:bg-red-50 transition-all active:scale-95">
               <span className="text-[10px] font-black uppercase tracking-[0.3em]">Logout Session</span>
               <span className="text-lg">➔</span>
             </button>
           </div>
        </div>
      )}

      {/* Concierge Booking Dialog */}
      {selectedService && (
        <div className="fixed inset-0 z-[100] dark-glass flex items-end sm:items-center justify-center">
          <div className="bg-white w-full max-w-md rounded-t-[3.5rem] sm:rounded-[3.5rem] p-10 shadow-premium animate-in slide-in-from-bottom-full duration-700 max-h-[92vh] overflow-y-auto no-scrollbar relative">
            <div className="flex justify-center gap-3 mb-10">
              {[1, 2, 3].map(i => (
                <div key={i} className={`h-1 rounded-full transition-all duration-700 ${step >= i ? 'w-12 bg-amber-500' : 'w-4 bg-slate-100'}`}></div>
              ))}
            </div>

            <div className="flex justify-between items-center mb-10 text-left">
              <div>
                <p className="text-[9px] font-black text-amber-500 uppercase tracking-[0.4em] mb-1">Booking Step {step}</p>
                <h3 className="text-2xl font-extrabold text-slate-950 tracking-tighter">
                  {step === 1 ? 'Select Pro' : step === 2 ? 'Details' : step === 3 ? 'Confirm' : 'Success'}
                </h3>
              </div>
              {step < 4 && <button onClick={() => { setStep(1); setSelectedService(null); }} className="w-11 h-11 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-950 transition-colors">✕</button>}
            </div>

            {step === 1 && (
              <div className="space-y-4 pb-6">
                {filteredBarbers.map(barber => {
                  const badge = getProximityBadge(barber);
                  return (
                    <button 
                      key={barber.id} onClick={() => { setSelectedBarber(barber); setStep(2); }}
                      className="w-full flex items-center gap-5 p-5 border border-slate-100 rounded-[2.2rem] transition-all text-left group relative overflow-hidden hover:border-amber-500/50 hover:bg-slate-50/50 active:scale-[0.98]"
                    >
                      <img src={barber.avatar} className="w-14 h-14 rounded-2xl object-cover" alt="" />
                      <div className="flex-1">
                        <p className="font-extrabold text-slate-950 text-base">{barber.name}</p>
                        <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest mt-0.5">{badge.text}</p>
                      </div>
                      <span className="text-base font-black text-slate-950">${getServicePrice(barber, selectedService)}</span>
                    </button>
                  );
                })}
              </div>
            )}

            {step === 2 && (
              <div className="space-y-8 animate-in slide-in-from-right-8 duration-500 text-left">
                <div className="space-y-4 bg-slate-50/50 p-7 rounded-[2.5rem] border border-slate-100 shadow-inner">
                  <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Venue Location</h4>
                  <LocationSelector initialValue={bookingArea} onSelect={setBookingArea} />
                </div>

                <div className="space-y-5">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Address / Street</label>
                    <input type="text" placeholder="House 123, Floor 2" value={address} onChange={(e) => setAddress(e.target.value)} className="w-full p-5 bg-slate-50 rounded-2xl font-bold text-slate-950 outline-none text-sm focus:bg-white border border-transparent focus:border-amber-500/20 transition-all shadow-inner" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Date</label>
                      <input type="date" className="w-full p-4 bg-slate-50 rounded-2xl font-black text-slate-950 outline-none text-xs border border-transparent focus:border-amber-500/20 shadow-inner" min={new Date().toISOString().split('T')[0]} onChange={(e) => setBookingDate(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Hour</label>
                      <select onChange={(e) => setBookingTime(e.target.value)} className="w-full p-4 bg-slate-50 rounded-2xl font-black text-slate-950 outline-none text-xs appearance-none border border-transparent focus:border-amber-500/20 shadow-inner">
                        <option value="">Choose</option>
                        {TIME_SLOTS.map(t => <option key={t} value={t}>{t}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                <button 
                  disabled={!bookingDate || !bookingTime || !bookingArea} 
                  onClick={() => setStep(3)} 
                  className="w-full bg-slate-950 text-white py-6 rounded-[2.2rem] font-black uppercase tracking-[0.3em] text-xs shadow-premium active:scale-95 transition-all disabled:opacity-20"
                >
                  Verify Details
                </button>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-8 animate-in zoom-in-95 duration-500 text-left">
                <div className="bg-slate-950 rounded-[3rem] p-10 text-white shadow-premium relative overflow-hidden">
                   <div className="relative z-10 space-y-8">
                     <div className="flex justify-between items-center border-b border-white/10 pb-6">
                        <div className="space-y-1">
                          <p className="text-[8px] font-black text-white/40 uppercase tracking-[0.3em]">Service</p>
                          <h4 className="text-xl font-extrabold tracking-tight">{selectedService.name}</h4>
                        </div>
                        <h4 className="text-2xl font-black text-amber-400">${currentPrice}</h4>
                     </div>
                     <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-1">
                          <p className="text-[8px] font-black text-white/40 uppercase tracking-[0.3em]">Specialist</p>
                          <p className="font-bold text-sm">{selectedBarber?.name}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[8px] font-black text-white/40 uppercase tracking-[0.3em]">Timing</p>
                          <p className="font-bold text-sm">{bookingDate} @ {bookingTime}</p>
                        </div>
                     </div>
                     <div className="space-y-1">
                        <p className="text-[8px] font-black text-white/40 uppercase tracking-[0.3em]">Destination</p>
                        <p className="font-bold text-xs opacity-70 leading-relaxed truncate">
                          {address || 'Primary Area'}, {bookingArea?.village}
                        </p>
                     </div>
                   </div>
                   <div className="absolute right-[-10%] bottom-[-10%] text-[12rem] text-white opacity-[0.02] font-black select-none italic">BAR</div>
                </div>
                <button onClick={handleCreateBooking} className="w-full bg-amber-500 text-slate-950 py-6 rounded-[2.2rem] font-black uppercase tracking-[0.3em] text-xs shadow-xl shadow-amber-500/10 active:scale-95 transition-all">Finalize Session</button>
              </div>
            )}

            {step === 4 && (
              <div className="text-center py-10 space-y-10 animate-in zoom-in-95 duration-700">
                <div className="w-24 h-24 bg-emerald-500 text-white rounded-[2.5rem] flex items-center justify-center mx-auto text-5xl shadow-premium animate-bounce">✓</div>
                <div>
                  <h4 className="text-3xl font-extrabold text-slate-950 tracking-tighter">Confirmed</h4>
                  <p className="text-slate-400 text-sm mt-3 px-10 leading-relaxed font-medium">Your pro is notified and will arrive promptly at the selected time.</p>
                </div>
                <button onClick={() => { setStep(1); setSelectedService(null); setActiveTab('bookings'); }} className="w-full bg-slate-950 text-white py-6 rounded-[2.2rem] font-black uppercase tracking-[0.3em] text-xs shadow-premium active:scale-95 transition-all">View Dashboard</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modern High-End Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 glass border-t border-slate-50/50 px-14 py-8 flex justify-between items-center z-[70] max-w-md mx-auto rounded-t-[3.5rem] shadow-premium">
        <button onClick={() => setActiveTab('home')} className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'home' ? 'text-slate-950 scale-105' : 'text-slate-300 hover:text-slate-400'}`}>
           <div className={`p-2.5 rounded-2xl transition-all ${activeTab === 'home' ? 'bg-slate-950 text-white shadow-lg' : 'bg-transparent'}`}>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
           </div>
           <span className="text-[7px] font-black uppercase tracking-[0.3em]">{activeTab === 'home' ? '•' : 'Home'}</span>
        </button>
        <button onClick={() => setActiveTab('bookings')} className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'bookings' ? 'text-slate-950 scale-105' : 'text-slate-300 hover:text-slate-400'}`}>
           <div className={`p-2.5 rounded-2xl transition-all ${activeTab === 'bookings' ? 'bg-slate-950 text-white shadow-lg' : 'bg-transparent'}`}>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
           </div>
           <span className="text-[7px] font-black uppercase tracking-[0.3em]">{activeTab === 'bookings' ? '•' : 'Vault'}</span>
        </button>
        <button onClick={() => setActiveTab('profile')} className={`flex flex-col items-center gap-1.5 transition-all ${activeTab === 'profile' ? 'text-slate-950 scale-105' : 'text-slate-300 hover:text-slate-400'}`}>
           <div className={`p-2.5 rounded-2xl transition-all ${activeTab === 'profile' ? 'bg-slate-950 text-white shadow-lg' : 'bg-transparent'}`}>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
           </div>
           <span className="text-[7px] font-black uppercase tracking-[0.3em]">{activeTab === 'profile' ? '•' : 'User'}</span>
        </button>
      </nav>
    </div>
  );
};

export default UserPanel;
