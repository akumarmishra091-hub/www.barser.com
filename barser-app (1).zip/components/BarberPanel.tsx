
import React, { useState } from 'react';
import { User, Booking, BookingStatus } from '../types';

interface BarberPanelProps {
  barber: User;
  bookings: Booking[];
  onUpdateStatus: (bookingId: string, status: BookingStatus) => void;
}

const BarberPanel: React.FC<BarberPanelProps> = ({ barber, bookings, onUpdateStatus }) => {
  const [activeTab, setActiveTab] = useState<'requests' | 'schedule' | 'earnings'>('requests');
  const [isOnline, setIsOnline] = useState(true);

  const barberBookings = bookings.filter(b => b.barberId === barber.id);
  const pendingRequests = barberBookings.filter(b => b.status === BookingStatus.PENDING);
  const upcomingBookings = barberBookings.filter(b => b.status === BookingStatus.ACCEPTED);
  const completedBookings = barberBookings.filter(b => b.status === BookingStatus.COMPLETED);

  const totalEarnings = completedBookings.reduce((sum, b) => sum + b.totalPrice, 0) * 0.95;

  return (
    <div className="flex flex-col h-full bg-slate-50">
      {activeTab === 'requests' && (
        <div className="p-8 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="bg-white p-8 rounded-[3rem] shadow-sm flex flex-col gap-4 border border-slate-100">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-black text-slate-950 tracking-tight">{isOnline ? 'Active Now' : 'Offline'}</h2>
                <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mt-1 italic">Ready for Jobs</p>
              </div>
              <button 
                onClick={() => setIsOnline(!isOnline)}
                className={`w-16 h-9 rounded-full p-1.5 transition-all ${isOnline ? 'bg-amber-500' : 'bg-slate-200'}`}
              >
                <div className={`w-6 h-6 bg-white rounded-full shadow-lg transition-all transform ${isOnline ? 'translate-x-7' : 'translate-x-0'}`}></div>
              </button>
            </div>
            {barber.location && (
              <div className="pt-4 border-t border-slate-50 flex items-center justify-between">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Service Area</span>
                <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest bg-amber-50 px-3 py-1 rounded-full">📍 {barber.location.village}</span>
              </div>
            )}
          </div>

          <h3 className="text-xl font-black text-slate-900 ml-2 tracking-tight text-left">New Requests</h3>
          {pendingRequests.length === 0 ? (
            <div className="text-center py-32 bg-white rounded-[3rem] border border-dashed border-slate-200">
              <span className="text-7xl mb-6 block">🕶️</span>
              <p className="text-slate-400 font-bold px-12">No requests yet. Stay online to get discovered!</p>
            </div>
          ) : (
            <div className="space-y-6">
              {pendingRequests.map(req => (
                <div key={req.id} className="bg-white rounded-[3rem] p-8 shadow-2xl shadow-slate-200/50 border border-slate-50 space-y-8 animate-in zoom-in-95 duration-300">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-4">
                       <div className="w-14 h-14 bg-amber-500 text-slate-950 rounded-2xl flex items-center justify-center text-2xl font-black">{req.userName.charAt(0)}</div>
                       <div>
                         <h4 className="font-black text-slate-950 text-lg tracking-tight text-left">{req.userName}</h4>
                         <p className="text-[10px] font-black text-slate-400 mt-1 uppercase tracking-widest italic text-left">{req.location?.village || 'Local Delivery'}</p>
                       </div>
                    </div>
                    <div className="bg-slate-950 text-white px-5 py-2.5 rounded-2xl font-black text-sm shadow-xl shadow-slate-950/10">
                      ${req.totalPrice}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-slate-50 p-4 rounded-3xl text-center">
                       <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Session</p>
                       <p className="text-xs font-black text-slate-700 uppercase tracking-tighter">{req.serviceName}</p>
                    </div>
                    <div className="bg-slate-50 p-4 rounded-3xl text-center">
                       <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Time</p>
                       <p className="text-xs font-black text-slate-700 uppercase tracking-tighter">{req.time}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <button onClick={() => onUpdateStatus(req.id, BookingStatus.REJECTED)} className="py-5 bg-slate-100 text-slate-400 text-xs font-black uppercase tracking-widest rounded-[2rem] hover:bg-red-50 hover:text-red-500 transition-all shadow-sm">Ignore</button>
                    <button onClick={() => onUpdateStatus(req.id, BookingStatus.ACCEPTED)} className="py-5 bg-amber-500 text-slate-950 text-xs font-black uppercase tracking-[0.2em] rounded-[2rem] shadow-xl shadow-amber-500/20 active:scale-95 transition-all">Accept Job</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'schedule' && (
        <div className="p-8 space-y-8 animate-in fade-in duration-300 text-left">
          <h2 className="text-3xl font-black text-slate-950 tracking-tight">Today's Schedule</h2>
          {upcomingBookings.length === 0 ? (
            <div className="text-center py-32 bg-white rounded-[3.5rem]">
              <span className="text-7xl mb-6 block">☕</span>
              <p className="text-slate-400 font-bold px-12">Relax, no jobs scheduled for now.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingBookings.map(booking => (
                <div key={booking.id} className="bg-white rounded-[2.5rem] p-6 shadow-sm border-l-[10px] border-amber-500 flex justify-between items-center group">
                  <div>
                    <div className="flex items-center gap-3">
                       <span className="text-sm font-black text-amber-600 uppercase tracking-widest">{booking.time}</span>
                       <span className="text-lg font-black text-slate-950 tracking-tight">{booking.userName}</span>
                    </div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">{booking.serviceName} • {booking.location?.village}</p>
                  </div>
                  <button onClick={() => onUpdateStatus(booking.id, BookingStatus.COMPLETED)} className="w-14 h-14 bg-green-500 text-white rounded-[1.8rem] flex items-center justify-center text-2xl shadow-xl shadow-green-100 active:scale-90 transition-all">✓</button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {activeTab === 'earnings' && (
        <div className="p-8 space-y-8 animate-in fade-in duration-300">
          <div className="bg-slate-950 rounded-[3.5rem] p-12 text-white shadow-3xl relative overflow-hidden text-center">
             <div className="relative z-10 space-y-6">
               <p className="text-white/40 text-[10px] font-black uppercase tracking-[0.3em]">Total Balance</p>
               <h2 className="text-6xl font-black tracking-tighter text-amber-500">${totalEarnings.toFixed(2)}</h2>
               <div className="inline-block px-5 py-2 bg-white/5 rounded-full text-[10px] font-black uppercase tracking-widest text-white/60">Includes 5% Fee</div>
               <button className="w-full mt-10 bg-white text-slate-950 py-6 rounded-[2rem] text-sm font-black uppercase tracking-[0.2em] shadow-2xl active:scale-95 transition-all">
                 Withdraw Funds
               </button>
             </div>
             <div className="absolute right-[-20%] bottom-[-10%] text-[20rem] text-white opacity-[0.03] font-black select-none">$$</div>
          </div>

          <div className="grid grid-cols-2 gap-6">
             <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 text-center space-y-2">
               <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest">Jobs Done</p>
               <p className="text-4xl font-black text-slate-950">{completedBookings.length}</p>
             </div>
             <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 text-center space-y-2">
               <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest">Satisfaction</p>
               <div className="flex items-center justify-center gap-2">
                 <span className="text-4xl font-black text-slate-950">{barber.rating}</span>
                 <span className="text-amber-500 text-2xl animate-pulse">★</span>
               </div>
             </div>
          </div>
        </div>
      )}

      {/* Modern Bottom Nav - 'Real' Icon Style */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-2xl border-t border-slate-100 px-12 py-7 flex justify-between items-center z-[70] max-w-md mx-auto rounded-t-[3.5rem] shadow-[0_-20px_60px_rgba(0,0,0,0.08)]">
        <button onClick={() => setActiveTab('requests')} className={`flex flex-col items-center gap-2 group transition-all ${activeTab === 'requests' ? 'text-slate-950 scale-110' : 'text-slate-300 hover:text-slate-400'}`}>
           <div className={`p-2 rounded-2xl transition-all ${activeTab === 'requests' ? 'bg-amber-500/10 text-amber-600' : 'bg-transparent'}`}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
            </svg>
           </div>
           <span className="text-[9px] font-black uppercase tracking-[0.15em]">{activeTab === 'requests' ? '•' : 'Requests'}</span>
        </button>
        <button onClick={() => setActiveTab('schedule')} className={`flex flex-col items-center gap-2 group transition-all ${activeTab === 'schedule' ? 'text-slate-950 scale-110' : 'text-slate-300 hover:text-slate-400'}`}>
           <div className={`p-2 rounded-2xl transition-all ${activeTab === 'schedule' ? 'bg-amber-500/10 text-amber-600' : 'bg-transparent'}`}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
            </svg>
           </div>
           <span className="text-[9px] font-black uppercase tracking-[0.15em]">{activeTab === 'schedule' ? '•' : 'Calendar'}</span>
        </button>
        <button onClick={() => setActiveTab('earnings')} className={`flex flex-col items-center gap-2 group transition-all ${activeTab === 'earnings' ? 'text-slate-950 scale-110' : 'text-slate-300 hover:text-slate-400'}`}>
           <div className={`p-2 rounded-2xl transition-all ${activeTab === 'earnings' ? 'bg-amber-500/10 text-amber-600' : 'bg-transparent'}`}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
           </div>
           <span className="text-[9px] font-black uppercase tracking-[0.15em]">{activeTab === 'earnings' ? '•' : 'Wallet'}</span>
        </button>
      </nav>
    </div>
  );
};

export default BarberPanel;
