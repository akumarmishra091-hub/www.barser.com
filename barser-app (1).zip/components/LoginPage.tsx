
import React, { useState } from 'react';
import { User, UserRole, AreaLocation } from '../types';
import { MOCK_USERS } from '../constants';
import LocationSelector from './LocationSelector';

interface LoginPageProps {
  onLogin: (user: User) => void;
}

type AuthMode = 'welcome' | 'login' | 'signup' | 'otp';

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<AuthMode>('welcome');
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', role: UserRole.USER });
  const [area, setArea] = useState<AreaLocation | null>(null);
  const [otp, setOtp] = useState(['', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError('');
  };

  const handleOtpChange = (val: string, index: number) => {
    if (isNaN(Number(val))) return;
    const newOtp = [...otp];
    newOtp[index] = val.slice(-1);
    setOtp(newOtp);
    if (val && index < 3) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === 'signup' && !area) {
      setError('Choose your service area');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      if (mode === 'login') {
        const user = MOCK_USERS.find(u => u.phone === formData.phone || u.email === formData.phone);
        if (user) setMode('otp');
        else setError('Account not recognized.');
      } else if (mode === 'otp') {
        if (otp.join('') === '1234' || otp.every(v => v !== '')) {
          const user = MOCK_USERS.find(u => u.phone === formData.phone || u.email === formData.phone) || MOCK_USERS[0];
          onLogin(user);
        } else setError('Invalid access code.');
      } else {
        onLogin({ 
          ...MOCK_USERS[0], 
          name: formData.name, 
          role: formData.role, 
          location: area || undefined,
          id: `u-${Date.now()}` 
        });
      }
      setLoading(false);
    }, 1800);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center relative overflow-hidden px-6">
      {/* Decorative Orbs */}
      <div className="absolute top-[-20%] left-[-20%] w-[80%] h-[80%] bg-amber-600/10 rounded-full blur-[140px] animate-pulse"></div>
      <div className="absolute bottom-[-20%] right-[-20%] w-[60%] h-[60%] bg-blue-900/10 rounded-full blur-[120px]"></div>
      
      <div className="w-full max-w-md relative z-10 py-10 overflow-y-auto no-scrollbar max-h-[95vh]">
        
        {mode === 'welcome' && (
          <div className="space-y-16 text-center animate-in fade-in zoom-in-95 duration-1000">
            <div className="space-y-8">
              <div className="w-28 h-28 bg-white rounded-[2.8rem] flex items-center justify-center mx-auto shadow-2xl rotate-3 animate-float-soft">
                <span className="text-5xl">✂️</span>
              </div>
              <div className="space-y-3">
                <h1 className="text-6xl font-black text-white tracking-tighter italic">Barser</h1>
                <p className="text-slate-400 text-sm font-black uppercase tracking-[0.4em]">Elite Home Grooming</p>
              </div>
            </div>

            <div className="space-y-5 px-4 pt-10">
              <button 
                onClick={() => setMode('signup')}
                className="w-full bg-white text-slate-950 py-6 rounded-[2.2rem] font-black uppercase tracking-[0.3em] text-xs shadow-2xl shadow-white/5 active:scale-95 transition-all"
              >
                Join Private Beta
              </button>
              <button 
                onClick={() => setMode('login')}
                className="w-full dark-glass border border-white/10 text-white py-6 rounded-[2.2rem] font-black uppercase tracking-[0.3em] text-xs active:scale-95 transition-all"
              >
                Member Access
              </button>
            </div>
            <p className="text-slate-600 text-[9px] font-black uppercase tracking-[0.5em] mt-10">Limited Availability</p>
          </div>
        )}

        {(mode === 'login' || mode === 'signup' || mode === 'otp') && (
          <div className="dark-glass border border-white/5 rounded-[3.5rem] p-10 shadow-premium animate-in slide-in-from-bottom-20 duration-1000">
            <button 
              onClick={() => setMode(mode === 'otp' ? 'login' : 'welcome')} 
              className="text-slate-500 hover:text-white mb-10 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest transition-colors"
            >
              ← Return
            </button>

            <div className="mb-12">
              <h2 className="text-4xl font-extrabold text-white tracking-tighter">
                {mode === 'login' ? 'Welcome' : mode === 'signup' ? 'Enrollment' : 'Verification'}
              </h2>
              <p className="text-slate-500 text-xs mt-3 font-medium leading-relaxed">
                {mode === 'otp' ? 'Security code dispatched to your mobile.' : 'Precision grooming delivered to your door.'}
              </p>
            </div>

            <form onSubmit={handleAction} className="space-y-7">
              {mode === 'signup' && (
                <div className="space-y-7">
                  <div className="space-y-5">
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Full Identity</label>
                      <input 
                        name="name" type="text" placeholder="e.g. Alexander Pierce" required
                        className="w-full bg-white/5 border border-white/10 p-5 rounded-2xl text-white outline-none focus:border-amber-500/40 focus:bg-white/10 transition-all font-bold text-sm"
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Your Role</label>
                      <select 
                        name="role" 
                        className="w-full bg-white/5 border border-white/10 p-5 rounded-2xl text-white outline-none focus:border-amber-500/40 focus:bg-white/10 transition-all font-bold text-sm appearance-none"
                        onChange={handleInputChange}
                      >
                        <option value={UserRole.USER} className="bg-slate-900">Member (Customer)</option>
                        <option value={UserRole.BARBER} className="bg-slate-900">Artisan (Barber)</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="pt-6 border-t border-white/10">
                    <h4 className="text-[9px] font-black text-amber-500 uppercase tracking-[0.4em] mb-5">Primary Locale</h4>
                    <LocationSelector onSelect={setArea} dark={true} />
                  </div>
                </div>
              )}

              {(mode === 'login' || mode === 'signup') && (
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Credential (Phone)</label>
                  <div className="relative">
                    <span className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 font-black">+</span>
                    <input 
                      name="phone" type="tel" placeholder="Mobile Number" required
                      className="w-full bg-white/5 border border-white/10 p-5 pl-10 rounded-2xl text-white outline-none focus:border-amber-500/40 focus:bg-white/10 transition-all font-bold text-sm"
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
              )}

              {mode === 'otp' && (
                <div className="flex justify-between gap-4 py-4">
                  {otp.map((digit, i) => (
                    <input
                      key={i} id={`otp-${i}`} type="text" maxLength={1} value={digit}
                      onChange={(e) => handleOtpChange(e.target.value, i)}
                      className="w-16 h-18 bg-white/5 border border-white/10 rounded-2xl text-center text-3xl font-black text-white outline-none focus:border-amber-500 focus:bg-white/10 transition-all shadow-inner"
                      required
                    />
                  ))}
                </div>
              )}

              {error && <p className="text-[9px] font-black text-red-400 uppercase tracking-widest text-center animate-pulse">{error}</p>}

              <button 
                type="submit" disabled={loading}
                className="w-full bg-white text-slate-950 py-6 rounded-2xl font-black uppercase tracking-[0.3em] text-xs shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-4 disabled:opacity-40"
              >
                {loading ? <div className="w-5 h-5 border-2 border-slate-950/20 border-t-slate-950 rounded-full animate-spin"></div> : (mode === 'otp' ? 'Validate' : 'Proceed')}
              </button>
            </form>

            <div className="mt-14 pt-10 border-t border-white/5 text-center">
               <p className="text-[8px] font-black text-slate-600 uppercase tracking-[0.4em] mb-8">Fast Access</p>
               <div className="flex justify-center gap-6">
                  <button onClick={() => onLogin(MOCK_USERS[0])} className="w-14 h-14 bg-white/5 rounded-2xl border border-white/10 flex items-center justify-center text-2xl hover:bg-white hover:text-slate-950 transition-all shadow-lg shadow-black/20">👤</button>
                  <button onClick={() => onLogin(MOCK_USERS[1])} className="w-14 h-14 bg-white/5 rounded-2xl border border-white/10 flex items-center justify-center text-2xl hover:bg-white hover:text-slate-950 transition-all shadow-lg shadow-black/20">🧔</button>
                  <button onClick={() => onLogin(MOCK_USERS[4])} className="w-14 h-14 bg-white/5 rounded-2xl border border-white/10 flex items-center justify-center text-2xl hover:bg-white hover:text-slate-950 transition-all shadow-lg shadow-black/20">⚙️</button>
               </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoginPage;
