
import React, { useState } from 'react';
import { User, Booking, UserRole } from '../types';
import { MOCK_USERS } from '../constants';

interface AdminPanelProps {
  bookings: Booking[];
}

const AdminPanel: React.FC<AdminPanelProps> = ({ bookings }) => {
  const [view, setView] = useState<'stats' | 'users' | 'barbers'>('stats');

  const totalRevenue = bookings.reduce((sum, b) => sum + b.totalPrice, 0);
  const platformCommission = totalRevenue * 0.05;

  const users = MOCK_USERS.filter(u => u.role === UserRole.USER);
  const barbers = MOCK_USERS.filter(u => u.role === UserRole.BARBER);

  return (
    <div className="p-8 space-y-10 animate-in fade-in duration-300 bg-slate-50 h-full">
      <div className="flex bg-white p-2 rounded-[2.5rem] shadow-sm border border-slate-100">
        {(['stats', 'users', 'barbers'] as const).map((v) => (
          <button 
            key={v}
            onClick={() => setView(v)}
            className={`flex-1 py-4 text-[10px] font-black uppercase tracking-[0.3em] rounded-[1.8rem] transition-all ${view === v ? 'bg-slate-950 text-white shadow-2xl' : 'text-slate-400 hover:text-slate-600'}`}
          >
            {v === 'stats' ? 'Overview' : v}
          </button>
        ))}
      </div>

      {view === 'stats' && (
        <div className="space-y-10">
          <div className="grid grid-cols-1 gap-8">
            <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 p-10 rounded-[3.5rem] text-white shadow-2xl relative overflow-hidden">
              <p className="text-white/40 text-[10px] font-black uppercase tracking-[0.3em]">Platform Profit</p>
              <h4 className="text-5xl font-black mt-3 tracking-tighter">${platformCommission.toFixed(2)}</h4>
              <p className="text-[10px] font-bold mt-6 bg-white/10 inline-block px-4 py-1.5 rounded-full text-white/80 tracking-widest uppercase">Barser Fees</p>
              <div className="absolute right-[-10%] bottom-[-10%] text-[15rem] text-white opacity-5 font-black select-none tracking-tighter">BAR</div>
            </div>

            <div className="bg-white p-10 rounded-[3.5rem] shadow-sm border border-slate-100 relative">
              <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.3em]">Gross Marketplace Value</p>
              <h4 className="text-4xl font-black text-slate-950 mt-3 tracking-tighter">${totalRevenue.toFixed(2)}</h4>
              <div className="mt-6 flex items-center gap-3">
                <span className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse shadow-lg shadow-green-200"></span>
                <span className="text-[10px] font-black text-green-600 uppercase tracking-widest italic">Live Metrics Tracking</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {view === 'barbers' && (
        <div className="space-y-8">
          <div className="flex justify-between items-center px-2">
             <h3 className="text-2xl font-black text-slate-950 tracking-tight">Pro Partners</h3>
             <button className="bg-slate-950 text-white p-3 rounded-2xl text-[10px] font-black uppercase tracking-widest px-6 shadow-xl active:scale-95 transition-all">+ Add Pro</button>
          </div>
          <div className="space-y-4">
            {barbers.map(barber => (
              <div key={barber.id} className="bg-white p-6 rounded-[3rem] shadow-sm border border-slate-100 flex items-center gap-5 group hover:border-amber-500 transition-all">
                <div className="relative">
                  <img src={barber.avatar} className="w-16 h-16 rounded-[1.8rem] object-cover" alt="" />
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 border-4 border-white rounded-full"></div>
                </div>
                <div className="flex-1">
                  <p className="font-black text-slate-950 text-lg tracking-tight">{barber.name}</p>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">★ {barber.rating} Partner</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {view === 'users' && (
        <div className="space-y-8">
          <h3 className="text-2xl font-black text-slate-950 tracking-tight px-2">Customers</h3>
          <div className="space-y-4">
            {users.map(user => (
              <div key={user.id} className="bg-white p-6 rounded-[3rem] shadow-sm border border-slate-100 flex items-center justify-between group hover:shadow-2xl transition-all">
                <div className="flex items-center gap-5">
                   <div className="w-16 h-16 bg-slate-950 rounded-[1.8rem] flex items-center justify-center font-black text-white text-2xl">
                     {user.name.charAt(0)}
                   </div>
                   <div>
                      <p className="font-black text-slate-950 text-lg tracking-tight">{user.name}</p>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1 italic">{user.phone}</p>
                   </div>
                </div>
                <button className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 hover:text-slate-950 hover:bg-white transition-all">➔</button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
