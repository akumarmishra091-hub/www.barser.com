
import React, { useState, useEffect } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { AreaLocation } from '../types';

interface LocationSelectorProps {
  onSelect: (location: AreaLocation) => void;
  initialValue?: AreaLocation;
  dark?: boolean;
}

const LocationSelector: React.FC<LocationSelectorProps> = ({ onSelect, initialValue, dark = false }) => {
  const [isSearching, setIsSearching] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [location, setLocation] = useState<AreaLocation>(initialValue || {
    country: '', state: '', district: '', subDistrict: '', village: ''
  });
  const [mode, setMode] = useState<'smart' | 'manual'>(initialValue?.country ? 'manual' : 'smart');

  // Trigger parent update when location changes
  useEffect(() => {
    if (location.country && location.state && (location.village || location.subDistrict)) {
      onSelect(location);
    }
  }, [location, onSelect]);

  const handleDetectLocation = () => {
    if (!navigator.geolocation) return;
    setIsSearching(true);
    navigator.geolocation.getCurrentPosition(async (pos) => {
      try {
        const { latitude, longitude } = pos.coords;
        const ai = new GoogleGenAI({ apiKey: (process.env as any).API_KEY });
        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: `Given coordinates ${latitude}, ${longitude}, return the structured address as JSON: {country, state, district, subDistrict, village}. Use common names.`,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                country: { type: Type.STRING },
                state: { type: Type.STRING },
                district: { type: Type.STRING },
                subDistrict: { type: Type.STRING },
                village: { type: Type.STRING },
              },
              required: ["country", "state"]
            }
          }
        });
        const result = JSON.parse(response.text || '{}');
        setLocation(result);
        setMode('manual');
      } catch (e) {
        console.error("AI Location Parse Failed", e);
      } finally {
        setIsSearching(false);
      }
    }, () => setIsSearching(false));
  };

  const handleSmartSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    try {
      const ai = new GoogleGenAI({ apiKey: (process.env as any).API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Resolve this location string into a structured JSON address: "${searchQuery}". Format: {country, state, district, subDistrict, village}. Ensure the state is the correct full name.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              country: { type: Type.STRING },
              state: { type: Type.STRING },
              district: { type: Type.STRING },
              subDistrict: { type: Type.STRING },
              village: { type: Type.STRING },
            },
            required: ["country", "state"]
          }
        }
      });
      const result = JSON.parse(response.text || '{}');
      setLocation(result);
      setMode('manual');
    } catch (e) {
      console.error("Smart Search Failed", e);
    } finally {
      setIsSearching(false);
    }
  };

  const inputClass = `w-full p-4 rounded-2xl text-sm font-bold outline-none border transition-all ${
    dark 
      ? 'bg-white/5 border-white/10 text-white placeholder:text-white/20 focus:border-amber-500/50' 
      : 'bg-slate-50 border-slate-100 text-slate-800 placeholder:text-slate-300 focus:border-amber-500/50 shadow-inner'
  }`;

  const labelClass = `text-[9px] font-black uppercase tracking-[0.2em] mb-2 block ${
    dark ? 'text-slate-500' : 'text-slate-400'
  }`;

  return (
    <div className="space-y-6">
      {/* Mode Toggle */}
      <div className={`flex p-1 rounded-2xl ${dark ? 'bg-white/5' : 'bg-slate-100'}`}>
        <button 
          onClick={() => setMode('smart')}
          className={`flex-1 py-2 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${mode === 'smart' ? (dark ? 'bg-white/10 text-white' : 'bg-white text-slate-950 shadow-sm') : 'text-slate-500'}`}
        >
          AI Search
        </button>
        <button 
          onClick={() => setMode('manual')}
          className={`flex-1 py-2 text-[9px] font-black uppercase tracking-widest rounded-xl transition-all ${mode === 'manual' ? (dark ? 'bg-white/10 text-white' : 'bg-white text-slate-950 shadow-sm') : 'text-slate-500'}`}
        >
          Detailed
        </button>
      </div>

      {mode === 'smart' ? (
        <div className="space-y-4 animate-in fade-in zoom-in-95 duration-300">
          <div className="relative">
            <input 
              type="text" 
              placeholder="City, State or Area..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSmartSearch()}
              className={`${inputClass} pr-12`}
            />
            <button 
              onClick={handleSmartSearch}
              disabled={isSearching}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-amber-500 rounded-xl flex items-center justify-center text-slate-950 shadow-lg disabled:opacity-50"
            >
              {isSearching ? '...' : '➔'}
            </button>
          </div>
          <button 
            onClick={handleDetectLocation}
            disabled={isSearching}
            className={`w-full py-4 rounded-2xl border flex items-center justify-center gap-3 transition-all ${dark ? 'bg-white/5 border-white/10 text-white/60 hover:text-white hover:bg-white/10' : 'bg-white border-slate-100 text-slate-500 hover:text-slate-950'}`}
          >
            <span className="text-lg">📍</span>
            <span className="text-[10px] font-black uppercase tracking-widest">Detect My Area</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>Country</label>
              <input 
                type="text" value={location.country} 
                onChange={(e) => setLocation({...location, country: e.target.value})}
                placeholder="e.g. USA" className={inputClass} 
              />
            </div>
            <div>
              <label className={labelClass}>State</label>
              <input 
                type="text" value={location.state} 
                onChange={(e) => setLocation({...location, state: e.target.value})}
                placeholder="e.g. NY" className={inputClass} 
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={labelClass}>District</label>
              <input 
                type="text" value={location.district} 
                onChange={(e) => setLocation({...location, district: e.target.value})}
                placeholder="e.g. Manhattan" className={inputClass} 
              />
            </div>
            <div>
              <label className={labelClass}>Area/Village</label>
              <input 
                type="text" value={location.village} 
                onChange={(e) => setLocation({...location, village: e.target.value})}
                placeholder="e.g. Chelsea" className={inputClass} 
              />
            </div>
          </div>
          <button 
            onClick={() => setMode('smart')}
            className={`text-[9px] font-black uppercase tracking-widest text-center mt-2 ${dark ? 'text-white/20 hover:text-white/40' : 'text-slate-300 hover:text-slate-400'}`}
          >
            Switch to AI Search
          </button>
        </div>
      )}

      {location.country && (
        <div className={`p-4 rounded-2xl flex items-center gap-4 animate-in zoom-in-95 duration-500 ${dark ? 'bg-amber-500/10 border border-amber-500/20' : 'bg-slate-50 border border-slate-100'}`}>
          <div className="w-10 h-10 bg-amber-500 rounded-xl flex items-center justify-center text-lg shadow-lg shadow-amber-500/20">🌍</div>
          <div>
            <p className={`text-[9px] font-black uppercase tracking-widest ${dark ? 'text-amber-500' : 'text-amber-600'}`}>Target Location</p>
            <p className={`text-xs font-bold truncate max-w-[200px] ${dark ? 'text-white' : 'text-slate-950'}`}>
              {location.village ? `${location.village}, ` : ''}{location.state}, {location.country}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default LocationSelector;
