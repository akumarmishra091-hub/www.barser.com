
import { Service, User, UserRole, Booking, BookingStatus } from './types';

export const SERVICES: Service[] = [
  { id: 's1', name: 'Classic Haircut', price: 25, duration: '45 min', category: 'Hair', icon: '✂️' },
  { id: 's2', name: 'Beard Grooming', price: 15, duration: '30 min', category: 'Beard', icon: '🧔' },
  { id: 's3', name: 'Royal Facial', price: 40, duration: '60 min', category: 'Skin', icon: '💆' },
  { id: 's4', name: 'Hair Color', price: 50, duration: '90 min', category: 'Hair', icon: '🎨' },
  { id: 's5', name: 'Head Massage', price: 20, duration: '20 min', category: 'Relax', icon: '🧘' },
];

export const MOCK_USERS: User[] = [
  { 
    id: 'u1', 
    name: 'John Doe', 
    email: 'john@example.com', 
    phone: '1234567890', 
    role: UserRole.USER, 
    avatar: 'https://picsum.photos/200?random=1',
    location: { country: 'India', state: 'Maharashtra', district: 'Pune', subDistrict: 'Haveli', village: 'Balewadi' }
  },
  { 
    id: 'b1', 
    name: 'Alex Sharp', 
    email: 'alex@barber.com', 
    phone: '9876543210', 
    role: UserRole.BARBER, 
    avatar: 'https://picsum.photos/200?random=2', 
    rating: 4.8, 
    isVerified: true,
    location: { country: 'India', state: 'Maharashtra', district: 'Pune', subDistrict: 'Haveli', village: 'Balewadi' },
    servicePrices: { 's1': 30, 's2': 12 }
  },
  { 
    id: 'b2', 
    name: 'Mark Fade', 
    email: 'mark@barber.com', 
    phone: '5554443332', 
    role: UserRole.BARBER, 
    avatar: 'https://picsum.photos/200?random=3', 
    rating: 4.5, 
    isVerified: true,
    location: { country: 'USA', state: 'New York', district: 'Manhattan', subDistrict: 'Chelsea', village: 'West 14th' },
    servicePrices: { 's1': 45, 's2': 25 }
  },
  { 
    id: 'b3', 
    name: 'Suresh Pro', 
    email: 'suresh@barber.com', 
    phone: '8887776665', 
    role: UserRole.BARBER, 
    avatar: 'https://picsum.photos/200?random=10', 
    rating: 4.9, 
    isVerified: true,
    location: { country: 'India', state: 'Maharashtra', district: 'Pune', subDistrict: 'Mulshi', village: 'Pirangut' },
    servicePrices: { 's1': 25, 's3': 35 }
  },
  { id: 'a1', name: 'Admin Master', email: 'admin@barserapp.com', phone: '0000000000', role: UserRole.ADMIN, avatar: 'https://picsum.photos/200?random=4' },
];

export const MOCK_BOOKINGS: Booking[] = [
  {
    id: 'bk1',
    userId: 'u1',
    barberId: 'b1',
    serviceId: 's1',
    date: '2023-11-20',
    time: '14:30',
    status: BookingStatus.COMPLETED,
    totalPrice: 30,
    address: '123 Maple Street, NY',
    userName: 'John Doe',
    serviceName: 'Classic Haircut',
    barberName: 'Alex Sharp',
    timestamp: 1700490600000
  }
];
