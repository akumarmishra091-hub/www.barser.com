
import React, { useState, useCallback } from 'react';
import Layout from './components/Layout';
import UserPanel from './components/UserPanel';
import BarberPanel from './components/BarberPanel';
import AdminPanel from './components/AdminPanel';
import LoginPage from './components/LoginPage';
import { User, UserRole, Booking, BookingStatus, AppNotification } from './types';
import { MOCK_USERS, MOCK_BOOKINGS } from './constants';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [bookings, setBookings] = useState<Booking[]>(MOCK_BOOKINGS);
  const [toasts, setToasts] = useState<AppNotification[]>([]);

  // Real-time Notification logic
  const showToast = useCallback((message: string, type: 'info' | 'success' | 'warning' | 'error' = 'info') => {
    const id = `toast-${Date.now()}`;
    const newToast: AppNotification = { id, message, type, timestamp: Date.now() };
    setToasts(prev => [...prev, newToast]);
    
    // Auto remove after 4 seconds
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    showToast(`Welcome back, ${user.name}!`, 'success');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    showToast('Logged out successfully', 'info');
  };

  const handleAddBooking = (newBooking: Booking) => {
    setBookings(prev => [...prev, newBooking]);
    showToast(`New Booking Confirmed: ${newBooking.serviceName}`, 'success');
  };

  const handleUpdateBookingStatus = (bookingId: string, status: BookingStatus) => {
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking) return;

    setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status } : b));
    
    if (status === BookingStatus.ACCEPTED) {
      showToast(`Booking accepted for ${booking.userName}`, 'success');
    } else if (status === BookingStatus.REJECTED) {
      showToast(`Booking rejected`, 'warning');
    } else if (status === BookingStatus.COMPLETED) {
      showToast(`Booking marked as completed`, 'success');
    }
  };

  if (!currentUser) {
    return (
      <>
        {/* Toast Notification Container for Login Page too */}
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] w-full max-w-[320px] space-y-2 pointer-events-none">
          {toasts.map(toast => (
            <div 
              key={toast.id}
              className={`p-3 rounded-xl shadow-lg border text-xs font-bold transition-all transform animate-in slide-in-from-top-4 pointer-events-auto ${
                toast.type === 'success' ? 'bg-green-500 text-white border-green-400' :
                toast.type === 'warning' ? 'bg-amber-500 text-white border-amber-400' :
                toast.type === 'error' ? 'bg-red-500 text-white border-red-400' :
                'bg-slate-800 text-white border-slate-700'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className="text-base">
                  {toast.type === 'success' ? '✅' : toast.type === 'warning' ? '⚠️' : toast.type === 'error' ? '❌' : '🔔'}
                </span>
                {toast.message}
              </div>
            </div>
          ))}
        </div>
        <LoginPage onLogin={handleLogin} />
      </>
    );
  }

  return (
    <Layout 
      title="Barser App" 
      role={currentUser.role}
    >
      {/* Toast Notification Container */}
      <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] w-full max-w-[320px] space-y-2 pointer-events-none">
        {toasts.map(toast => (
          <div 
            key={toast.id}
            className={`p-3 rounded-xl shadow-lg border text-xs font-bold transition-all transform animate-in slide-in-from-top-4 pointer-events-auto ${
              toast.type === 'success' ? 'bg-green-500 text-white border-green-400' :
              toast.type === 'warning' ? 'bg-amber-500 text-white border-amber-400' :
              toast.type === 'error' ? 'bg-red-500 text-white border-red-400' :
              'bg-slate-800 text-white border-slate-700'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="text-base">
                {toast.type === 'success' ? '✅' : toast.type === 'warning' ? '⚠️' : toast.type === 'error' ? '❌' : '🔔'}
              </span>
              {toast.message}
            </div>
          </div>
        ))}
      </div>

      {currentUser.role === UserRole.USER && (
        <UserPanel 
          user={currentUser} 
          bookings={bookings.filter(b => b.userId === currentUser.id)} 
          allBookings={bookings}
          onAddBooking={handleAddBooking} 
          onLogout={handleLogout}
        />
      )}

      {currentUser.role === UserRole.BARBER && (
        <BarberPanel 
          barber={currentUser} 
          bookings={bookings} 
          onUpdateStatus={handleUpdateBookingStatus} 
        />
      )}

      {currentUser.role === UserRole.ADMIN && (
        <AdminPanel 
          bookings={bookings} 
        />
      )}
    </Layout>
  );
};

export default App;
