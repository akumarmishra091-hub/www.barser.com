
export enum UserRole {
  USER = 'USER',
  BARBER = 'BARBER',
  ADMIN = 'ADMIN'
}

export enum BookingStatus {
  PENDING = 'PENDING',
  ACCEPTED = 'ACCEPTED',
  REJECTED = 'REJECTED',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

export interface AreaLocation {
  country: string;
  state: string;
  district: string;
  subDistrict: string;
  village: string;
}

export interface Service {
  id: string;
  name: string;
  price: number;
  duration: string;
  category: string;
  icon: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar: string;
  address?: string;
  location?: AreaLocation;
  rating?: number;
  isVerified?: boolean;
  servicePrices?: Record<string, number>;
}

export interface Booking {
  id: string;
  userId: string;
  barberId: string;
  serviceId: string;
  date: string;
  time: string;
  status: BookingStatus;
  totalPrice: number;
  address: string;
  location?: AreaLocation;
  userName: string;
  serviceName: string;
  barberName: string;
  timestamp: number;
}

export interface Review {
  id: string;
  bookingId: string;
  rating: number;
  comment: string;
  userName: string;
  date: string;
}

export interface AppNotification {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: number;
}
